<?php
/*
    Plugin Name: Plenopay Payment Method
    Plugin URI: https://plenopay.com/
    Description: Agrega Plenopay como método de pago en WooCommerce. Al confirmar el pedido se abre una ventana emergente de Plenopay (Unlimit).
    Author: Plenopay
    Author URI: https://www.plenopay.com/integracion-woocommerce
    License: MIT
    Version: 2.0.11
*/

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── WooCommerce active check ─────────────────────────────────────────────────

function wc_plenopay_is_active() {
    if ( class_exists( 'WooCommerce' ) ) return true;
    $plugins = apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) );
    if ( in_array( 'woocommerce/woocommerce.php', $plugins, true ) ) return true;
    if ( is_multisite() ) {
        return isset( get_site_option( 'active_sitewide_plugins', [] )['woocommerce/woocommerce.php'] );
    }
    return false;
}

if ( ! wc_plenopay_is_active() ) return;

// ─── Hooks ────────────────────────────────────────────────────────────────────

add_action( 'before_woocommerce_init',             'wc_plenopay_declare_hpos_compatibility' );
add_action( 'plugins_loaded',                      'wc_plenopay_gateway_init', 11 );
add_action( 'woocommerce_blocks_loaded',           'wc_plenopay_register_blocks_support' );
add_action( 'wp_enqueue_scripts',                  'wc_plenopay_enqueue_checkout_scripts' );
add_filter( 'woocommerce_payment_gateways',        'wc_plenopay_add_to_gateways' );
add_action( 'woocommerce_before_add_to_cart_form', 'wc_plenopay_product_banner' );
add_action( 'woocommerce_before_cart_totals',      'wc_plenopay_cart_banner' );
add_action( 'wp_ajax_plenopay_order_amounts',      'wc_plenopay_ajax_order_amounts' );
add_action( 'wp_ajax_nopriv_plenopay_order_amounts', 'wc_plenopay_ajax_order_amounts' );

// ─── Compatibility ────────────────────────────────────────────────────────────

function wc_plenopay_declare_hpos_compatibility() {
    if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables',  __FILE__, true );
    }
}

// ─── Gateway registration ─────────────────────────────────────────────────────

function wc_plenopay_add_to_gateways( $gateways ) {
    $gateways[] = 'WC_Gateway_Plenopay';
    return $gateways;
}

function wc_plenopay_gateway_init() {
    if ( class_exists( 'WC_Gateway_Plenopay' ) ) return;

    class WC_Gateway_Plenopay extends WC_Payment_Gateway {

        public function __construct() {
            $this->id                 = 'plenopay';
            $this->icon               = plugin_dir_url( __FILE__ ) . 'boton_logo_plenopay-02.png';
            $this->method_title       = __( 'Plenopay', 'woocommerce-plenopay-gateway' );
            $this->method_description = __( 'Paga en 4 cuotas con Plenopay. Se abre una ventana emergente al confirmar el pedido.', 'woocommerce-plenopay-gateway' );
            $this->has_fields         = false;
            $this->supports           = [ 'products' ];

            $this->init_form_fields();
            $this->init_settings();

            $this->enabled     = $this->get_option( 'enabled' );
            $this->title       = $this->get_option( 'title' );
            $this->description = $this->get_option( 'description' );

            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );
            add_action( 'woocommerce_api_plenopay', [ $this, 'webhook' ] );
        }

        public function is_available() {
            if ( 'yes' !== $this->enabled ) return false;
            if ( empty( $this->get_option( 'idCommerce' ) ) || empty( $this->get_option( 'keyCommerce' ) ) ) return false;
            return parent::is_available();
        }

        public function get_icon() {
            $icon_html = $this->icon ? '<img src="' . esc_url( $this->icon ) . '" alt="' . esc_attr( $this->get_title() ) . '" style="height:20px;vertical-align:middle;" />' : '';
            return apply_filters( 'woocommerce_gateway_icon', $icon_html, $this->id );
        }

        public function init_form_fields() {
            $this->form_fields = [
                'enabled' => [
                    'title'   => __( 'Habilitar/Deshabilitar', 'woocommerce-plenopay-gateway' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'Plenopay habilitado', 'woocommerce-plenopay-gateway' ),
                    'default' => 'yes',
                ],
                'idCommerce' => [
                    'title'       => __( 'ID de Comercio', 'woocommerce-plenopay-gateway' ),
                    'type'        => 'number',
                    'description' => __( 'ID de comercio en Plenopay', 'woocommerce-plenopay-gateway' ),
                    'default'     => '',
                    'desc_tip'    => true,
                ],
                'keyCommerce' => [
                    'title'       => __( 'Llave de Comercio (API Key)', 'woocommerce-plenopay-gateway' ),
                    'type'        => 'text',
                    'description' => __( 'Clave pública del comercio', 'woocommerce-plenopay-gateway' ),
                    'default'     => '',
                    'desc_tip'    => true,
                ],
                'title' => [
                    'title'   => __( 'Título', 'woocommerce-plenopay-gateway' ),
                    'type'    => 'text',
                    'default' => __( 'Plenopay - 4 pagos c/15 días con Tarjeta de Crédito y Débito.', 'woocommerce-plenopay-gateway' ),
                ],
                'description' => [
                    'title'   => __( 'Descripción', 'woocommerce-plenopay-gateway' ),
                    'type'    => 'textarea',
                    'default' => __( 'Paga hoy sólo el 25% de tu compra. Al confirmar, se abrirá una ventana de Plenopay para completar tu pago.', 'woocommerce-plenopay-gateway' ),
                ],
                'apiUrl' => [
                    'title'       => __( 'URL del Backend (API)', 'woocommerce-plenopay-gateway' ),
                    'type'        => 'text',
                    'description' => __( 'URL base de la API de Plenopay (sin barra al final)', 'woocommerce-plenopay-gateway' ),
                    'default'     => 'https://api.plenopay.com',
                    'desc_tip'    => true,
                ],
                'platformUrl' => [
                    'title'       => __( 'URL de Platform_Plenopay', 'woocommerce-plenopay-gateway' ),
                    'type'        => 'text',
                    'description' => __( 'URL base de la plataforma de pago (sin barra al final)', 'woocommerce-plenopay-gateway' ),
                    'default'     => 'https://pagos.plenopay.com',
                    'desc_tip'    => true,
                ],
                'sandbox' => [
                    'title'   => __( 'Sandbox / Producción', 'woocommerce-plenopay-gateway' ),
                    'type'    => 'select',
                    'options' => [
                        'true'  => __( 'Sandbox (Unlimit sandbox)', 'woocommerce-plenopay-gateway' ),
                        'false' => __( 'Producción', 'woocommerce-plenopay-gateway' ),
                    ],
                    'default' => 'true',
                ],
            ];
        }

        public function admin_options() {
            ?>
            <h3><?php _e( 'Plenopay Settings', 'woocommerce-plenopay-gateway' ); ?></h3>
            <table class="form-table">
                <?php $this->generate_settings_html(); ?>
            </table>
            <?php
        }

        /**
         * Called by WC after the checkout AJAX creates the order.
         * Sets order to pending-payment and returns the standard thankyou redirect.
         * The actual payment popup is opened by our checkout JS before the user
         * reaches the thankyou page.
         */
        public function process_payment( $order_id ) {
            $order = wc_get_order( $order_id );
            $order->update_status(
                'pending-payment',
                __( 'Esperando confirmación de pago vía Plenopay.', 'woocommerce-plenopay-gateway' )
            );
            WC()->cart->empty_cart();

            return [
                'result'   => 'success',
                'redirect' => $this->get_return_url( $order ),
            ];
        }

        public function webhook() {
            $order_id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
            $order    = wc_get_order( $order_id );

            if ( ! $order || strtolower( $order->get_payment_method() ) !== 'plenopay' ) {
                wp_die( 'Invalid request', '', [ 'response' => 400 ] );
            }

            $status      = sanitize_text_field( $_GET['status']      ?? '' );
            $id_plenopay = sanitize_text_field( $_GET['idPlenopay']  ?? '' );

            if ( $status === 'success' ) {
                $order->update_status( 'processing', sprintf(
                    __( 'Plenopay confirmó la compra (ID: %s). Verifica en comercios.plenopay.com.', 'woocommerce-plenopay-gateway' ),
                    esc_html( $id_plenopay )
                ) );
                $order->reduce_order_stock();
            } elseif ( $status === 'expired' ) {
                $order->update_status( 'cancelled', sprintf(
                    __( 'Plenopay canceló la compra (ID: %s).', 'woocommerce-plenopay-gateway' ),
                    esc_html( $id_plenopay )
                ) );
                wc_restock_refunded_items( $order, $order->get_items() );
            } elseif ( in_array( $status, [ 'rejected', 'declined', 'failed' ], true ) ) {
                $order->update_status( 'failed', sprintf(
                    __( 'Plenopay rechazó el pago (ID: %s).', 'woocommerce-plenopay-gateway' ),
                    esc_html( $id_plenopay )
                ) );
                wc_restock_refunded_items( $order, $order->get_items() );
            }

            update_option( 'webhook_debug', $_GET );
        }
    }
}

// ─── Checkout page JS injection ───────────────────────────────────────────────

function wc_plenopay_enqueue_checkout_scripts() {
    if ( ! is_checkout() || is_order_received_page() ) return;
    if ( ! WC()->cart ) return;

    $gateways = WC()->payment_gateways->payment_gateways();
    $gateway  = $gateways['plenopay'] ?? null;
    if ( ! $gateway || ! $gateway->is_available() ) return;

    // Build product list from current cart
    $products = [];
    foreach ( WC()->cart->get_cart() as $item ) {
        $qty        = max( 1, (int) $item['quantity'] );
        $products[] = [
            'name'     => $item['data']->get_name(),
            'amount'   => round( (float) $item['line_subtotal'] / $qty, 2 ),
            'quantity' => $qty,
        ];
    }

    $config = [
        'idCommerce'  => $gateway->get_option( 'idCommerce' ),
        'keyCommerce' => $gateway->get_option( 'keyCommerce' ),
        'apiUrl'      => rtrim( $gateway->get_option( 'apiUrl',      'https://api.plenopay.com' ),   '/' ),
        'platformUrl' => rtrim( $gateway->get_option( 'platformUrl', 'https://pagos.plenopay.com' ), '/' ),
        'sandbox'     => $gateway->get_option( 'sandbox', 'true' ),
        'products'    => $products,
        'shipping'    => round( (float) WC()->cart->get_shipping_total(), 2 ),
        'tax'         => round( (float) WC()->cart->get_cart_tax(), 2 ),
        'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
        'nonce'       => wp_create_nonce( 'plenopay_order_amounts' ),
    ];

    // Register a virtual script (no src) so we can attach inline scripts with a jQuery dependency
    wp_register_script( 'plenopay-checkout', false, [ 'jquery' ], null, true );
    wp_enqueue_script( 'plenopay-checkout' );

    // 1) Config object — uses PHP data, so we build it as JSON
    wp_add_inline_script(
        'plenopay-checkout',
        'var plenopayConfig = ' . wp_json_encode( $config ) . ';',
        'before'
    );

    // 2) Logic — nowdoc (no PHP interpolation); reads window.plenopayConfig
    wp_add_inline_script( 'plenopay-checkout', wc_plenopay_checkout_logic_js() );
}

// The 'shipping'/'tax' values above are captured once at initial checkout page load.
// WooCommerce recalculates them via its own AJAX (woocommerce_update_order_review)
// whenever the customer picks/changes a shipping method or address, without
// re-running this hook — so those values can go stale before the order is placed.
// This endpoint lets the checkout JS pull the real, final amounts straight from the
// order that WooCommerce just created, right before creating the Plenopay purchase.
function wc_plenopay_ajax_order_amounts() {
    check_ajax_referer( 'plenopay_order_amounts', 'nonce' );

    $order_id = isset( $_REQUEST['order_id'] ) ? absint( $_REQUEST['order_id'] ) : 0;
    $order    = $order_id ? wc_get_order( $order_id ) : false;

    if ( ! $order ) {
        wp_send_json_error( [ 'message' => 'Invalid order.' ], 404 );
    }

    wp_send_json_success( [
        'shipping' => round( (float) $order->get_shipping_total(), 2 ),
        'tax'      => round( (float) $order->get_total_tax(), 2 ),
    ] );
}

function wc_plenopay_checkout_logic_js() {
    // Nowdoc: no PHP variable interpolation — all $ are literal JS
    return <<<'JSEOF'
(function ($) {
    'use strict';

    var P               = window.plenopayConfig;
    var activePopup     = null;
    var pollInterval    = null;
    var thankyouUrl     = null;
    var paymentResolved = false;
    var messageHandler  = null;

    // WC 10.x fires checkout_place_order_{id} via $form.triggerHandler(), not document.body.
    // We must bind directly to the form. Returning false aborts WC's own AJAX so we
    // can run our own submission and open the popup instead of a full-page redirect.
    $(function () {
        $('form.checkout').on('checkout_place_order_plenopay', function () {
            handlePlenopayCheckout($(this));
            return false;
        });
    });

    // ── Step 0: submit WC checkout AJAX to create the order ──────────────────

    function handlePlenopayCheckout($form) {
        var $btn = $form.find('#place_order');
        $btn.prop('disabled', true).val('Procesando…');

        // wc_checkout_params.checkout_url is localised by WC itself
        var checkoutUrl = (typeof wc_checkout_params !== 'undefined')
            ? wc_checkout_params.checkout_url
            : '/?wc-ajax=checkout';

        $.ajax({
            type:     'POST',
            url:      checkoutUrl,
            data:     $form.serialize(),
            dataType: 'json',
            success: function (res) {
                if (res.result !== 'success') {
                    showWcError(res.messages || res.message || 'Error al procesar el pedido.');
                    resetBtn($btn);
                    return;
                }

                thankyouUrl = res.redirect;

                // Extract WC order ID from the thankyou URL
                var match   = (res.redirect || '').match(/order-received\/(\d+)/);
                var orderId = match ? parseInt(match[1], 10) : undefined;

                openPlenopayPopup(orderId);
            },
            error: function () {
                showWcError('Error de conexión. Intenta de nuevo.');
                resetBtn($btn);
            }
        });
    }

    // ── Steps 1-3: get tokens and open popup ──────────────────────────────────

    async function openPlenopayPopup(orderId) {
        try {
            // Refresh shipping/tax from the order WC just created — P.shipping/P.tax
            // were captured at initial page load and go stale if the customer changed
            // their shipping method/address afterwards (WC updates the review totals
            // via its own AJAX without re-running our PHP hook).
            if (orderId) {
                try {
                    var amountsRes = await jsonFetch(
                        P.ajaxUrl + '?action=plenopay_order_amounts'
                        + '&order_id=' + encodeURIComponent(orderId)
                        + '&nonce='    + encodeURIComponent(P.nonce)
                    );
                    if (amountsRes && amountsRes.data) {
                        if (typeof amountsRes.data.shipping === 'number') P.shipping = amountsRes.data.shipping;
                        if (typeof amountsRes.data.tax      === 'number') P.tax      = amountsRes.data.tax;
                    }
                } catch (e) { /* fall back to the page-load values if this fails */ }
            }

            // Step 1: commerce token
            var tokenUrl = P.apiUrl
                + '/pay-button/' + encodeURIComponent(P.idCommerce)
                + '?key='        + encodeURIComponent(P.keyCommerce)
                + '&sandbox='    + P.sandbox
                + '&justToken=true';

            var tokenRaw = await jsonFetch(tokenUrl);
            var commerceToken = (typeof tokenRaw === 'string')
                ? tokenRaw.replace(/^"|"$/g, '')
                : tokenRaw;

            if (typeof commerceToken !== 'string' || !/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(commerceToken)) {
                throw new Error('No se obtuvo el token del comercio. Verifica el ID y la llave.');
            }

            // Step 2: create purchase
            var purchaseBody = {
                products:    P.products,
                shippingFee: P.shipping,
                tax:         P.tax,
            };
            if (orderId) purchaseBody.orderId = orderId;

            var purchaseRes = await jsonFetch(P.apiUrl + '/purchases/create-order', {
                method:  'POST',
                headers: {
                    'Content-Type':  'application/json',
                    'Authorization': 'Bearer ' + commerceToken,
                },
                body: JSON.stringify(purchaseBody),
            });

            var purchaseToken = purchaseRes && (
                purchaseRes.token       ||
                (purchaseRes.data && purchaseRes.data.token)
            );

            if (!purchaseToken) {
                throw new Error('No se obtuvo el token de compra.');
            }

            // Step 3: open popup
            var popupUrl = P.platformUrl + '/' + purchaseToken
                + '?sandbox='    + P.sandbox
                + (orderId ? '&wcOrderId=' + encodeURIComponent(orderId) : '')
                + '&wcSiteUrl='  + encodeURIComponent(window.location.origin);
            var features = [
                'width=1030',
                'height=750',
                'left='  + Math.round((screen.width  - 1030) / 2),
                'top='   + Math.round((screen.height - 750) / 2),
                'resizable=yes',
                'scrollbars=yes',
                'toolbar=no',
                'menubar=no',
                'location=no',
                'status=no',
            ].join(',');

            activePopup = window.open(popupUrl, 'plenopay_payment', features);

            if (!activePopup || activePopup.closed) {
                throw new Error('El popup fue bloqueado por el navegador. Permite ventanas emergentes para este sitio e intenta de nuevo.');
            }

            // Derive expected origin from platformUrl (strip any path the admin may have added)
            var expectedOrigin;
            try { expectedOrigin = new URL(P.platformUrl).origin; } catch (e) { expectedOrigin = P.platformUrl; }

            // Listen for the outcome postMessage from Platform_Plenopay
            paymentResolved = false;
            if (messageHandler) window.removeEventListener('message', messageHandler);
            messageHandler = function (e) {
                if (e.origin !== expectedOrigin) return;
                if (!e.data || typeof e.data.plenopay === 'undefined') return;

                paymentResolved = true;
                clearInterval(pollInterval);
                window.removeEventListener('message', messageHandler);
                messageHandler = null;

                if (activePopup && !activePopup.closed) activePopup.close();
                activePopup = null;

                if (e.data.plenopay === 'success') {
                    window.location.href = thankyouUrl;
                } else {
                    showWcError('Tu pago fue rechazado por Plenopay. Intenta con otra tarjeta o método de pago.');
                    resetBtn($('form.checkout #place_order'));
                }
            };
            window.addEventListener('message', messageHandler);

            // Fallback: popup closed by the user (hit X) without sending a postMessage.
            // The WC order already exists as pending-payment — redirect to its status page
            // so the customer can see the order and retry later from their account.
            clearInterval(pollInterval);
            pollInterval = setInterval(function () {
                if (!activePopup || activePopup.closed) {
                    clearInterval(pollInterval);
                    activePopup = null;
                    if (!paymentResolved) {
                        window.removeEventListener('message', messageHandler);
                        messageHandler = null;
                        if (thankyouUrl) window.location.href = thankyouUrl;
                    }
                }
            }, 600);

        } catch (err) {
            showWcError('Plenopay: ' + (err.message || 'Error inesperado. Intenta de nuevo.'));
            resetBtn($('form.checkout #place_order'));
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    async function jsonFetch(url, opts) {
        var res  = await fetch(url, opts || {});
        var text = await res.text();
        var body;
        try { body = JSON.parse(text); } catch (e) { body = text; }
        if (!res.ok) {
            var msg = (body && Array.isArray(body.reasons) && body.reasons.length)
                ? body.reasons.map(function (r) { return r.message; }).join(', ')
                : ((body && body.message) ? body.message : ('HTTP ' + res.status));
            throw new Error(Array.isArray(msg) ? msg.join(', ') : msg);
        }
        return body;
    }

    function resetBtn($btn) {
        $btn.prop('disabled', false).val('Realizar el Pedido');
    }

    function showWcError(msg) {
        $('form.checkout .woocommerce-NoticeGroup-checkout, form.checkout .woocommerce-error').closest('.woocommerce-NoticeGroup').remove();
        var html = '<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout">'
                 + '<ul class="woocommerce-error" role="alert"><li>' + msg + '</li></ul>'
                 + '</div>';
        $('form.checkout').prepend(html);
        $('html, body').animate({ scrollTop: $('form.checkout').offset().top - 80 }, 300);
    }

}(jQuery));
JSEOF;
}

// ─── Blocks checkout support ──────────────────────────────────────────────────

function wc_plenopay_register_blocks_support() {
    if ( ! class_exists( '\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) return;
    if (   class_exists( 'WC_Gateway_Plenopay_Blocks' ) ) return;

    class WC_Gateway_Plenopay_Blocks extends \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {
        protected $name = 'plenopay';

        public function initialize() {
            $this->settings = get_option( 'woocommerce_plenopay_settings', [] );
        }

        public function is_active() {
            $gateways = WC()->payment_gateways->payment_gateways();
            $gateway  = $gateways['plenopay'] ?? null;
            return $gateway ? $gateway->is_available() : false;
        }

        public function get_payment_method_script_handles() {
            wp_register_script(
                'plenopay-blocks-integration',
                plugin_dir_url( __FILE__ ) . 'plenopay-blocks.js',
                [ 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ],
                '2.0.4',
                true
            );
            return [ 'plenopay-blocks-integration' ];
        }

        public function get_payment_method_data() {
            $gateways = WC()->payment_gateways->payment_gateways();
            $gateway  = $gateways['plenopay'] ?? null;

            // Build current cart product list so the blocks JS can call create-order
            $products = [];
            if ( WC()->cart ) {
                foreach ( WC()->cart->get_cart() as $item ) {
                    $qty        = max( 1, (int) $item['quantity'] );
                    $products[] = [
                        'name'     => $item['data']->get_name(),
                        'amount'   => round( (float) $item['line_subtotal'] / $qty, 2 ),
                        'quantity' => $qty,
                    ];
                }
            }

            return [
                'title'       => $gateway ? $gateway->get_title()       : __( 'Plenopay', 'woocommerce-plenopay-gateway' ),
                'description' => $gateway ? $gateway->get_description() : '',
                'supports'    => [ 'products' ],
                'idCommerce'  => $gateway ? $gateway->get_option( 'idCommerce' )  : '',
                'keyCommerce' => $gateway ? $gateway->get_option( 'keyCommerce' ) : '',
                'apiUrl'      => $gateway ? rtrim( $gateway->get_option( 'apiUrl',      'https://api.plenopay.com' ),   '/' ) : 'https://api.plenopay.com',
                'platformUrl' => $gateway ? rtrim( $gateway->get_option( 'platformUrl', 'https://pagos.plenopay.com' ), '/' ) : 'https://pagos.plenopay.com',
                'sandbox'     => $gateway ? $gateway->get_option( 'sandbox', 'true' ) : 'true',
                'products'    => $products,
                'shipping'    => WC()->cart ? round( (float) WC()->cart->get_shipping_total(), 2 ) : 0,
                'tax'         => WC()->cart ? round( (float) WC()->cart->get_cart_tax(),        2 ) : 0,
                'iconUrl'     => plugin_dir_url( __FILE__ ) . 'boton_logo_plenopay-02.png',
            ];
        }
    }

    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function ( $registry ) { $registry->register( new WC_Gateway_Plenopay_Blocks() ); }
    );
}

// ─── Product page banner ──────────────────────────────────────────────────────

function wc_plenopay_product_banner() {
    $params = wc_plenopay_commerce_param();
    $apiUrl = wc_plenopay_banner_api_url();
    global $product;
    $price = (float) $product->get_price();
    ?>
    <style>.plenopay-mi{margin:0!important}.plenopay-mh{padding:0!important}.plenopay-mp{padding:0!important}</style>
    <div id="plenopay-product-banner" style="display:flex;flex-wrap:wrap;align-items:center;justify-content:flex-end;margin-bottom:15px;">
        o págalo en <span style="color:#000000;font-weight:bold;margin:0 4px;">4 cuotas</span>
        de <b style="display:flex;margin:0 5px;">$<span id="plenopay-cuota"></span></b>
        con <img src="<?php echo esc_url( plugin_dir_url( __FILE__ ) . 'boton_logo_plenopay-02.png' ); ?>" style="width:90px;margin:0 8px;" alt="Plenopay" />
        <span style="color:#1a4bcd;cursor:pointer;text-decoration:underline #1a4bcd" onclick="plenopayInfoAlert()">Conoce más.</span>
    </div>
    <script>
    function plenopayInfoAlert() {
        Swal.fire({ title:'', text:'', imageUrl:'<?php echo esc_js( plugin_dir_url( __FILE__ ) . 'CHECKOUTbox-plenopay.png' ); ?>', imageAlt:'Plenopay', showConfirmButton:false, showCloseButton:true, customClass:{image:'plenopay-mi',header:'plenopay-mh',popup:'plenopay-mp'} });
    }
    (async function() {
        try {
            var r = await fetch('<?php echo esc_js( $apiUrl ); ?>/purchases/amounts<?php echo esc_js( $params ); ?>');
            var d = await r.json();
            var amount = <?php echo esc_js( $price ); ?>;
            if (amount >= d.min && amount <= d.max) {
                document.getElementById('plenopay-cuota').textContent = (amount / 4).toFixed(2);
            } else {
                document.getElementById('plenopay-product-banner').style.display = 'none';
            }
        } catch(e) { document.getElementById('plenopay-product-banner').style.display = 'none'; }
    })();
    </script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <?php
}

// ─── Cart banner ──────────────────────────────────────────────────────────────

function wc_plenopay_cart_banner() {
    $params      = wc_plenopay_commerce_param();
    $apiUrl      = wc_plenopay_banner_api_url();
    global $woocommerce;
    $cart_total  = (float) $woocommerce->cart->total;
    ?>
    <style>.plenopay-mi{margin:0!important}.plenopay-mh{padding:0!important}.plenopay-mp{padding:0!important}</style>
    <div id="plenopay-cart-banner" style="display:flex;flex-wrap:wrap;align-items:center;justify-content:flex-end;margin-bottom:15px;">
        o págalo en <span style="color:#000000;font-weight:bold;margin:0 4px;">4 cuotas</span>
        con <img src="<?php echo esc_url( plugin_dir_url( __FILE__ ) . 'boton_logo_plenopay-02.png' ); ?>" style="width:90px;margin:0 8px;" alt="Plenopay" />
        <span style="color:#1a4bcd;cursor:pointer;text-decoration:underline #1a4bcd" onclick="plenopayInfoAlert()">Conoce más.</span>
    </div>
    <script>
    if (typeof plenopayInfoAlert === 'undefined') {
        function plenopayInfoAlert() {
            Swal.fire({ title:'', text:'', imageUrl:'<?php echo esc_js( plugin_dir_url( __FILE__ ) . 'CHECKOUTbox-plenopay.png' ); ?>', imageAlt:'Plenopay', showConfirmButton:false, showCloseButton:true, customClass:{image:'plenopay-mi',header:'plenopay-mh',popup:'plenopay-mp'} });
        }
    }
    (async function() {
        try {
            var r = await fetch('<?php echo esc_js( $apiUrl ); ?>/purchases/amounts<?php echo esc_js( $params ); ?>');
            var d = await r.json();
            var amount = <?php echo esc_js( $cart_total ); ?>;
            if (!(amount >= d.min && amount <= d.max)) {
                document.getElementById('plenopay-cart-banner').style.display = 'none';
            }
        } catch(e) { document.getElementById('plenopay-cart-banner').style.display = 'none'; }
    })();
    </script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <?php
}

// ─── Shared helper ────────────────────────────────────────────────────────────

function wc_plenopay_get_gateway() {
    $gateways = WC()->payment_gateways->get_available_payment_gateways();
    foreach ( $gateways as $method ) {
        if ( stripos( $method->title, 'plenopay' ) !== false ) {
            return WC()->payment_gateways->payment_gateways()[ $method->id ] ?? null;
        }
    }
    return null;
}

function wc_plenopay_commerce_param() {
    $gw = wc_plenopay_get_gateway();
    if ( $gw ) {
        $id = $gw->get_option( 'idCommerce' );
        return $id ? '?id=' . rawurlencode( $id ) : '';
    }
    return '';
}

function wc_plenopay_banner_api_url() {
    $gw = wc_plenopay_get_gateway();
    return $gw ? rtrim( $gw->get_option( 'apiUrl', 'https://api.plenopay.com' ), '/' ) : 'https://api.plenopay.com';
}
